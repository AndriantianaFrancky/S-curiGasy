import React, { useState, useEffect } from 'react';
import './App.css';
import logo from './image/logo.png';
import AdminPanel from './admin';

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    email: '',
    adresse: '',
  });
  const [activeSection, setActiveSection] = useState('home');
  const [isNavbarOpen, setIsNavbarOpen] = useState(false);
  const [isNavbarVisible, setIsNavbarVisible] = useState(true);
  const [isContentVisible, setIsContentVisible] = useState(false);
  const [isUser, setIsUser] = useState(false);
  const [fadeEffect, setFadeEffect] = useState(false);
  const [showUserManagement, setShowUserManagement] = useState(false);
  const [isLoginFormVisible, setIsLoginFormVisible] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  useEffect(() => {
    let lastScrollY = window.scrollY;

    const handleScroll = () => {
      if (activeSection !== 'home') {
        setIsNavbarVisible(window.scrollY <= lastScrollY);
      } else {
        setIsNavbarVisible(true);
      }
      lastScrollY = window.scrollY;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [activeSection]);

  useEffect(() => {
    let hideNavbarTimeout;

    const handleMouseMove = () => {
      setIsNavbarVisible(true);
      clearTimeout(hideNavbarTimeout);
      hideNavbarTimeout = setTimeout(() => {
        setIsNavbarVisible(false);
      }, 2000);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    setTimeout(() => setIsContentVisible(true), 300);
  }, []);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
    alert('Inscription réussie !');
    closeModal();
  };

  const handleLinkClick = (section) => {
    setActiveSection(section);
    document.getElementById(section).scrollIntoView({ behavior: 'smooth' });
    setIsNavbarOpen(false);
  };

  const toggleUserAdmin = () => {
    setFadeEffect(true);
    setTimeout(() => {
      setIsUser(!isUser);
      setFadeEffect(false);
    }, 600);
  };

  const handleManageUsers = () => {
    setShowUserManagement(true);
  };

  const closeUserManagement = () => {
    setShowUserManagement(false);
  };

  const toggleLoginForm = () => {
    setIsLoginFormVisible(!isLoginFormVisible);
  };

  const handleAdminLogin = (e) => {
    e.preventDefault();
    setIsAdminLoggedIn(true);
    alert('Connexion administrateur réussie !');
  };

  return (
    <div id="root" className={isContentVisible ? 'content-visible' : ''}>
      <header>
        <nav className={`navbar ${isNavbarVisible ? '' : 'hidden'}`}>
          <a href="#"><img src={logo} alt="logo" className="navbar-logo" /></a>
          <button className="navbar-toggle" onClick={() => setIsNavbarOpen(!isNavbarOpen)}>☰</button>
          <ul className={`navbar-links ${isNavbarOpen ? 'open' : ''}`}>
            <li>
              <a
                href="#"
                className={activeSection === 'home' ? 'active' : ''}
                onClick={() => handleLinkClick('home')}
              >
                Accueil
              </a>
            </li>
            <li>
              <a
                href="#about"
                className={activeSection === 'about' ? 'active' : ''}
                onClick={() => handleLinkClick('about')}
              >
                À propos
              </a>
            </li>
            <li>
              <a
                href="#services"
                className={activeSection === 'services' ? 'active' : ''}
                onClick={() => handleLinkClick('services')}
              >
                Services
              </a>
            </li>
            <li>
              <a
                href="#contact"
                className={activeSection === 'contact' ? 'active' : ''}
                onClick={() => handleLinkClick('contact')}
              >
                Contact
              </a>
            </li>
            <li>
              <a
                href="#user"
                className={`navbar-link user-link ${activeSection === 'user' ? 'active' : ''}`}
                onClick={() => {
                  toggleUserAdmin();
                  handleLinkClick('user');
                }}
              >
                {isUser ? 'Admin' : 'User'}
              </a>
            </li>
          </ul>
        </nav>
        {activeSection === 'user' && (
          <div className={`infos ${fadeEffect ? 'slow-show' : ''}`}>
            {isUser ? (
              <>
                <h1>Bienvenue sur Securt-IT</h1>
                <p>
                  Découvrez nos services et apprenez-en plus sur ce que nous avons à offrir. 
                  Nous sommes là pour répondre à vos besoins avec professionnalisme et expertise.
                </p>
                <button className="signup-button" onClick={openModal}>S'inscrire</button>
              </>
            ) : (
              <>
                <h1>Admin Panel</h1>
                <p>
                  Bienvenue dans le panneau d'administration. Veuillez vous connecter pour accéder aux fonctionnalités administratives.
                </p>
                {!isAdminLoggedIn ? (
                  <form className="admin-login-form" onSubmit={handleAdminLogin}>
                    <label>
                      Email :
                      <input
                        type="email"
                        name="adminEmail"
                        placeholder="Entrez votre email"
                        required
                      />
                    </label>
                    <label>
                      Mot de passe :
                      <input
                        type="password"
                        name="adminPassword"
                        placeholder="Entrez votre mot de passe"
                        required
                      />
                    </label>
                    <button type="submit">Se connecter</button>
                  </form>
                ) : (
                  <div className="admin-buttons">
                    <button style={{ margin: '10px' }} onClick={handleManageUsers}>Gérer les utilisateurs</button>
                    <button style={{ margin: '10px' }} onClick={() => console.log('Voir les alertes')}>Voir les alertes</button>
                    <button style={{ margin: '10px' }} onClick={() => console.log('Paramètres de sécurité')}>Paramètres de sécurité</button>
                  </div>
                )}
              </>
            )}
          </div>
        )}
        {showUserManagement && (
          <div className="user-management">
            <h2>Gestion des utilisateurs</h2>
            <button onClick={closeUserManagement} style={{ marginBottom: '10px' }}>Fermer</button>
            <table>
              <thead>
                <tr>
                  <th>Nom</th>
                  <th>Email</th>
                  <th>Rôle</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Jean Dupont</td>
                  <td>jean.dupont@example.com</td>
                  <td>Utilisateur</td>
                  <td>
                    <button onClick={() => console.log('Modifier')}>Modifier</button>
                    <button onClick={() => console.log('Supprimer')}>Supprimer</button>
                  </td>
                </tr>
                <tr>
                  <td>Marie Curie</td>
                  <td>marie.curie@example.com</td>
                  <td>Administrateur</td>
                  <td>
                    <button onClick={() => console.log('Modifier')}>Modifier</button>
                    <button onClick={() => console.log('Supprimer')}>Supprimer</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </header>
      <section id="about" className="about-section blurred-background">
        <h2>À propos de nous</h2>
        <p>
          Ce site est dédié à garantir la sécurité urbaine de la population. 
          Les utilisateurs peuvent s'inscrire pour recevoir des informations directement sur leur email.
        </p>
        <p>
          Du côté administrateur, les alertes envoyées par les caméras ou les micros intégrés en cas de violence 
          sont immédiatement reçues. Ces alertes incluent la position exacte de l'incident, permettant une intervention rapide.
        </p>
        <div className="info-box-container">
          <div className="info-box">
            <h3>Notre Mission</h3>
            <p>Garantir la sécurité urbaine et protéger les citoyens grâce à des technologies avancées.</p>
          </div>
          <div className="info-box">
            <h3>Notre Vision</h3>
            <p>Créer un environnement urbain plus sûr grâce à l'innovation et à la connectivité.</p>
          </div>
          <div className="info-box">
            <h3>Nos Valeurs</h3>
            <p>Engagement, réactivité et protection des citoyens.</p>
          </div>
        </div>
      </section>
      <section id="services" className="services-section">
        <h2>Nos Services</h2>
        <div className="services-box-container">
          <div className="services-box">
            <h3>Surveillance en Temps Réel</h3>
            <p>
              Grâce à nos caméras et micros intégrés, nous offrons une surveillance en temps réel pour détecter 
              et signaler les incidents de sécurité.
            </p>
          </div>
          <div className="services-box">
            <h3>Alertes Automatiques</h3>
            <p>
              En cas de violence ou d'incident, des alertes automatiques sont envoyées avec la position exacte 
              pour une intervention rapide.
            </p>
          </div>
        </div>
      </section>
      <section id="contact" className="contact-section">
        <h2>Contact</h2>
        <div className="contact-box-container">
          <div className="contact-box">
            <h3>Ambulance</h3>
            <p><strong>Numéro :</strong> 118 218</p>
            <p><strong>Adresse :</strong> 12 Rue des Urgences, Bordeaux</p>
          </div>
          <div className="contact-box">
            <h3>Gendarmerie</h3>
            <p><strong>Numéro :</strong> 101</p>
            <p><strong>Adresse :</strong> 34 Avenue de la Défense, Lille</p>
          </div>
          <div className="contact-box">
            <h3>Hospital</h3>
            <p><strong>Numéro :</strong> 05 56 78 90 12</p>
            <p><strong>Adresse :</strong> 56 Boulevard de la Santé, Toulouse</p>
          </div>
        </div>
      </section>
      {isModalOpen && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={closeModal}>&times;</span>
            {!isLoginFormVisible ? (
              <>
                <h2>Formulaire d'inscription</h2>
                <form onSubmit={handleSubmit}>
                  <label>
                    Nom :
                    <input
                      type="text"
                      name="nom"
                      value={formData.nom}
                      onChange={handleChange}
                      required
                    />
                  </label>
                  <label>
                    Prénom :
                    <input
                      type="text"
                      name="prenom"
                      value={formData.prenom}
                      onChange={handleChange}
                      required
                    />
                  </label>
                  <label>
                    Email :
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </label>
                  <label>
                    Adresse :
                    <input
                      type="text"
                      name="adresse"
                      value={formData.adresse}
                      onChange={handleChange}
                      required
                    />
                  </label>
                  <button type="submit">S'inscrire</button>
                </form>
                <p className="form-link">
                  Déjà inscrit ? <a href="#" onClick={toggleLoginForm}>Connectez-vous ici</a>
                </p>
              </>
            ) : (
              <>
                <h2>Connexion</h2>
                <form onSubmit={(e) => {
                  e.preventDefault();
                  console.log('Email:', formData.email);
                  alert('Connexion réussie !');
                  closeModal();
                }}>
                  <label>
                    Email :
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </label>
                  <button type="submit">Se connecter</button>
                </form>
                <p className="form-link">
                  Pas encore inscrit ? <a href="#" onClick={toggleLoginForm}>Inscrivez-vous ici</a>
                </p>
              </>
            )}
          </div>
        </div>
      )}
      <footer className="footer">
        <div className="footer-container">
          <div className="footer-section">
            <h3>À propos</h3>
            <p>
              SecurtIT est une plateforme dédiée à la sécurité urbaine, offrant des solutions innovantes pour protéger les citoyens.
            </p>
          </div>
          <div className="footer-section">
            <h3>Liens Utiles</h3>
            <ul>
              <li><a href="#about">À propos</a></li>
              <li><a href="#services">Services</a></li>
              <li><a href="#contact">Contact</a></li>
              <li><a href="#home">Accueil</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h3>Contact</h3>
            <p>Email: contact@securtit.com</p>
            <p>Téléphone: +33 1 23 45 67 89</p>
            <p>Adresse: 123 Rue de la Sécurité, Paris</p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2023 SecurtIT. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
