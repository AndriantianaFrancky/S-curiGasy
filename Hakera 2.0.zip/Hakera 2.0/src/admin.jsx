import React from 'react';
import './admin.css';

const AdminPanel = () => {
    return (
        <div className="infos">
            <h1>Admin Panel</h1>
            <p>Welcome to the admin panel. Use the options below to manage the application.</p>
            <div className="info-box-container">
                <button className="admin-button">Manage Users</button>
                <button className="admin-button">View Reports</button>
                <button className="admin-button">Settings</button>
            </div>
        </div>
    );
};

export default AdminPanel;